package com.example.jbutter.aetnademo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.qualtrics.qsiframework.QualtricsIntercept;
import com.qualtrics.qsiframework.QualtricsInterceptManager;

public class MainActivity extends AppCompatActivity {

    Button mButton = null;
    QualtricsIntercept mQualtricsIntercept = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQualtricsIntercept = QualtricsInterceptManager.instance().createIntercept(
                this.getApplicationContext(),
                "SI_aic0izXG8FsK6Cp",
                "zn9prmknJnzyirhgh",
                "aetnadigital",
                true);
        mQualtricsIntercept.setVerboseLogging(true);
        mQualtricsIntercept.start();

        mButton = (Button)this.findViewById(R.id.survey_button);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mQualtricsIntercept.unload();
                mQualtricsIntercept.put("showSurvey", "true", false);
                mQualtricsIntercept.loadWithViewGroup((ViewGroup) findViewById(android.R.id.content));
            }
        });
    }
}
